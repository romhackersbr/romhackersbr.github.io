<?php
include '../../mainfile.php';
include XOOPS_ROOT_PATH.'/include/notification_update.php';
?>