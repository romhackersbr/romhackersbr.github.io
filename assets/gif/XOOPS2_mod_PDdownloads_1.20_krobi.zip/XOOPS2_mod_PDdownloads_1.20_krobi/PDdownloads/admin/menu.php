<?php
/**
 * $Id: index.php
 * Module: PD-Downloads
 * Version: v1.2
 * Release Date: 21. Dec 2005
 * Author: Power-Dreams Team
 * Licence: GNU
 */

$adminmenu[1]['title'] = _MI_PDD_BINDEX;
$adminmenu[1]['link'] = "admin/index.php";
$adminmenu[2]['title'] = _MI_PDD_INDEXPAGE;
$adminmenu[2]['link'] = "admin/indexpage.php";
$adminmenu[3]['title'] = _MI_PDD_MCATEGORY;
$adminmenu[3]['link'] = "admin/category.php";
$adminmenu[4]['title'] = _MI_PDD_MDOWNLOADS;
$adminmenu[4]['link'] = "admin/index.php?op=Download";
$adminmenu[5]['title'] = _MI_PDD_MUPLOADS;
$adminmenu[5]['link'] = "admin/upload.php";
$adminmenu[6]['title'] = _MI_PDD_MMIMETYPES;
$adminmenu[6]['link'] = "admin/mimetypes.php";
$adminmenu[7]['title'] = _MI_PDD_MVOTEDATA;
$adminmenu[7]['link'] = "admin/votedata.php";
$adminmenu[8]['title'] = _MI_PDD_PERMISSIONS;
$adminmenu[8]['link'] = "admin/permissions.php"; 
$adminmenu[9]['title'] = _MI_PDD_BLOCKADMIN;
$adminmenu[9]['link'] = "admin/myblocksadmin.php"; 

?>