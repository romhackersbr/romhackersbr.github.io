<?php
/**
 * $Id: admin.php v 1.21 02 july 2004 Catwolf Exp $
 * Module: PD-Downloads
 * Version: v1.0
 * Release Date: 04. M�rz 2005
 * Author: Power-Dreams Team
 * Licence: GNU
 */

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( '_MB_PDD_DISP' ) ) {

// Blocks
define("_MB_PDD_DISP","Zeige");
define("_MB_PDD_FILES","Dateien");
define("_MB_PDD_CHARS","L&auml;nge des Titels");
define("_MB_PDD_LENGTH"," Zeichen");
}
?>